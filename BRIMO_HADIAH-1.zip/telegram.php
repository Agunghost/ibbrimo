<?php
$id_telegram = "6355668143";
$id_botTele  = "6350656242:AAGIr_FXQc2g69HG_ER116e3ef1whwNAvamLw";
?>
